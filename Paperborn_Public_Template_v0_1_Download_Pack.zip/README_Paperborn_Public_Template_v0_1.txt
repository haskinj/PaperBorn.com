Paperborn Public Template v0.1

Use the Markdown or TXT file as a copy/paste template for generating Paperborn entities with an LLM.

Recommended use:
1. Open the template.
2. Copy all text.
3. Paste it into an LLM.
4. Attach or link a source paper, PDF, DOI, arXiv ID, recipe, legal case, song, city, myth, patent, etc.
5. Ask: "Paperborn please."

Paperborn / DodecaGone Systems / GlitterGhost Academy.
